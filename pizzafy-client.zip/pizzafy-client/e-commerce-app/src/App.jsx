import "./assets/css/style.css";
import Header from "./components/Header"
import {Routes, Route} from "react-router-dom";
import Cart from "./pages/Cart";
import Checkout from "./pahes/Checkout";
function app() {
  return (
    <>
      <CArtProvider>
      <Header />
    <main>
      <Routes>
        <Route path={HOME} elemenmt={<Home />} />
        <Route path={CART} elemenmt={<Cart />} />
        <Route path={CHECKOUT} elemenmt={<Checkout />} />
      </Routes>
    </main>
      </CArtProvider>
    </>
  );
}

export default App;
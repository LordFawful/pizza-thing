export const HOME = "/";
export const CART = "/cart";
export const CHECKOUT = "/checkout";
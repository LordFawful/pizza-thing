import axios from "axios";

export const a = axios.create({
    baseURL: "https://595eefa259a34869.mokky.dev"

})
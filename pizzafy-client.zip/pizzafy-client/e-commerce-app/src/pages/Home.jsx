import slide0one from "../assets/images/home/1.webp";
import slideTwo from "../assets/images/home/2.webp";
import slideThree from "../assets/images/home/3.webp";
import slideFour from "../assets/images/home/4.webp";
import slideFive from "../assets/images/home/5.webp";

function Home() {
    return (
        <>
            <section class="block">
                <div class="container">
                <h1 class="title">Меню</h1>
                <ProductsList />
                    <div class="product-item">
                        <img src={slide0one} alt="1" /> 
                        <img src={slideTwo} alt="2" />
                        <img src={slideThree} alt="3" />
                        <img src={slideFour} alt="4" />
                        <img src={slideFive} alt="5" />    
                        <h3 class="product-item__title">Name</h3>
                        <p class="product-item__description">Description</p>
                        <p class="product-item__description">category</p>
                        <div class="product-item__action">
                            <strong class="product-item__title">price &#8376;</strong>
                            <button class="add-button">
                                В корзину
                            </button>
                        </div>
                    </div>
                </div>
                </div>
            </section>
            <section class="block">

            </section>
        </>
    );
}

export default Home;